Coding test for AND Digital - Graduate Developer
I have added some very basic unit tests, as we were asked to showcase our coding skills,
even though it was not asked for in the challenge.